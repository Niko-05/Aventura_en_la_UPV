package controlador;
/*
 * Un Único stage y varias escenas que se van sustituyendo
 * jsanchez
 */
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

 

public class PrincipalControlador {
	
	private Stage primaryStage;
	
	public void initStage( Stage stage)
	{ primaryStage = stage;
	}
	
	 @FXML void irAVentana1(ActionEvent event) {
		 try {
		 primaryStage.setTitle("Ventana 1");
		 FXMLLoader miCargador  = new FXMLLoader(getClass().getResource("/vista/Ventana1.fxml"));
		 Parent root = miCargador.load();
         // acceso al controlador de ventana 1
		 Ventana1Controlador ventana1 = miCargador.getController();
	     ventana1.initStage(primaryStage);
		 Scene scene = new Scene(root,400,400);
		 primaryStage.setScene(scene);
		 primaryStage.show();
		 } catch (IOException e) {e.printStackTrace();}
	    }
	 
	 @FXML void pulsadoSalir(ActionEvent event) {
		primaryStage.hide();
	    }
	
}
