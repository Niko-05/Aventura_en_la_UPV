package controlador;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class PrincipalControlador {

	@FXML void irAVentana1(ActionEvent event) {

		 try { 
		    Stage estageActual = new Stage();
		    estageActual.setTitle("Ventana 1");
			
		    FXMLLoader miCargador = new FXMLLoader(getClass().getResource("/vista/Ventana1.fxml"));
		    Parent root = miCargador.load();
		    
		    Scene scene = new Scene(root,400,400);
		    estageActual.setScene(scene);
		    estageActual.initModality(Modality.APPLICATION_MODAL);
		    estageActual.show();
                    System.out.println(">>>>>>>>>>>>>>>");
                    
		 	} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		 	}
		 }   
	 
	 @FXML void salirAccion(ActionEvent event) {
	    Node n = (Node)event.getSource();	
            n.getScene().getWindow().hide();
	 }
	
}
