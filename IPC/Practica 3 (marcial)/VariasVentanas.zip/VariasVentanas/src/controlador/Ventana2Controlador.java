package controlador;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;


public class Ventana2Controlador {
		
	 @FXML void cerrarVentana2(ActionEvent event) {
         Node minodo = (Node) event.getSource();
         minodo.getScene().getWindow().hide();
         System.out.println("Cerrando ventana 2");
	 }

}
