package controlador;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class Ventana1Controlador {
	
	 @FXML void irAVentana2(ActionEvent event) {
		 try { Stage estageActual = new Stage();
		 estageActual.setTitle("Ventana 2");
		 FXMLLoader miCargador = new FXMLLoader(getClass().getResource("/vista/Ventana2.fxml"));
		 AnchorPane root = (AnchorPane) miCargador.load();
		 Scene scene = new Scene(root,400,400);
		 estageActual.setScene(scene);
		 estageActual.initModality(Modality.APPLICATION_MODAL);
		 estageActual.show();
	     }   catch (IOException e) {
			e.printStackTrace();
		 }  
	 }

	 @FXML void cerrarAccion(ActionEvent event) {
            // generado por un botón
            Node minodo = (Node) event.getSource();
            minodo.getScene().getWindow().hide();
	    System.out.println("Cerrando ventana 1");
	}
}
