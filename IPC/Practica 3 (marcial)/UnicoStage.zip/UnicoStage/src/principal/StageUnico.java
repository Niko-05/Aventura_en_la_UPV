package principal;
/*
 * jsanchez
 */
import controlador.PrincipalControlador;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;


public class StageUnico extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/vista/Principal.fxml"));
			Parent root = loader.load(); 
			Scene scene = new Scene(root,400,400);
			primaryStage.setTitle("Demo único stage varias escenas");
			primaryStage.setScene(scene);
			// acceso al controlador
			PrincipalControlador controladorPrincipal = loader.getController();
			controladorPrincipal.initStage(primaryStage);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
