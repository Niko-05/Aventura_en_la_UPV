package controlador;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Ventana1Controlador {
	
	private Stage primaryStage;
	private Scene escenaPrincipal; 
	
	public void initStage(Stage stage)
	{
		primaryStage = stage;
		escenaPrincipal = stage.getScene();
	}
	
	 @FXML void irAVentana2(ActionEvent event) {
         // no implementado en esta versión
		 

	  }
	 
	
	 @FXML void cerrarAccion(ActionEvent event) {

		   	System.out.println("Cerrando ventana 1");
		   	primaryStage.setTitle("Multi ventanas");
			primaryStage.setScene(escenaPrincipal);
			
	}

}
